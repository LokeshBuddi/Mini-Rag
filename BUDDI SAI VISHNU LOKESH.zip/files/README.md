# ⬡ iNDECIMAL RAG v2

A Retrieval-Augmented Generation system for the Indecimal construction
marketplace — rebuilt with a cleaner class-based architecture and an
industrial terminal-style UI.

---

## Project Structure

```
rag-v2/
├── data/                    ← Place .md / .pdf documents here
├── vector_store/            ← Auto-created FAISS index
├── core/
│   ├── loader.py            ← DocumentLoader class
│   ├── chunker.py           ← SentenceChunker class
│   ├── vector_store.py      ← VectorStore class (FAISS)
│   ├── llm.py               ← LLMClient class (OpenRouter)
│   └── engine.py            ← RAGEngine orchestrator
├── interface/
│   └── app.py               ← Streamlit UI (terminal aesthetic)
├── requirements.txt
└── .env.example
```

---

## Key Differences from v1

| Aspect | v1 | v2 |
|---|---|---|
| Code style | Functional (module-level functions) | Object-oriented (classes) |
| Entry point | `app/chatbot.py` | `interface/app.py` |
| UI theme | Light card-based | Dark industrial terminal |
| Chunk display | Vertical list | Responsive card grid with score bars |
| Hints | `st.info` text | Clickable query buttons |
| Engine naming | `RAGPipeline` | `RAGEngine` |

---

## Embedding Model

`sentence-transformers/all-MiniLM-L6-v2` — lightweight, 384-dim,
L2-normalised output (cosine = inner product for FAISS IndexFlatIP).

## Chunking Strategy

500-character chunks with 100-character overlap, split at sentence
boundaries where possible.

## Retrieval

FAISS `IndexFlatIP` — exact cosine similarity search over all
stored embeddings.

## Grounding

LLM is given only retrieved chunks as context and explicitly
instructed not to use outside knowledge.

---

## Running

```bash
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt

# Add docs
cp your-files.md data/

# Set API key
cp .env.example .env
# Edit .env with your OpenRouter key

# Run
streamlit run interface/app.py
```

Open `http://localhost:8501`

---

## Example Queries

- What packages does Indecimal offer?
- What is the price of the Premier package?
- How does the escrow payment model work?
- What does the maintenance program cover?
- How many quality checkpoints does Indecimal have?
- What steel brands are used in the Pinnacle package?
