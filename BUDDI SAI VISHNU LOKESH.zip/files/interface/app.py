"""
app.py  —  Indecimal RAG v2
Industrial terminal-style UI. Run with:
    streamlit run interface/app.py
"""

import os, sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import streamlit as st
from core.engine import RAGEngine
from dotenv import load_dotenv
 
# Load .env from the project root (one level up from app/)
load_dotenv(os.path.join(os.path.dirname(__file__), "..", ".env"))
# ── Page config ────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="iNDECIMAL · RAG",
    page_icon="⬡",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# ── CSS — Industrial terminal aesthetic ───────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@300;400;500;600&family=IBM+Plex+Sans:wght@300;400;600&display=swap');

/* ── Base ── */
html, body, [class*="css"] {
    font-family: 'IBM Plex Sans', sans-serif;
}

/* Background */
.stApp {
    background-color: #0d0d0d;
    background-image:
        linear-gradient(rgba(255,176,0,0.03) 1px, transparent 1px),
        linear-gradient(90deg, rgba(255,176,0,0.03) 1px, transparent 1px);
    background-size: 40px 40px;
}

/* Hide default streamlit chrome */
#MainMenu, footer, header { visibility: hidden; }
.block-container { padding-top: 2rem !important; max-width: 1100px; }

/* ── Top bar ── */
.topbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid #ffb000;
    padding-bottom: 1rem;
    margin-bottom: 2rem;
}
.topbar-logo {
    font-family: 'IBM Plex Mono', monospace;
    font-size: 1.3rem;
    font-weight: 600;
    color: #ffb000;
    letter-spacing: 0.1em;
    text-transform: uppercase;
}
.topbar-tag {
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.7rem;
    color: #555;
    letter-spacing: 0.2em;
    text-transform: uppercase;
}

/* ── Status bar ── */
.status-bar {
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.7rem;
    color: #444;
    letter-spacing: 0.15em;
    margin-bottom: 1.5rem;
    text-transform: uppercase;
}
.status-bar span { color: #ffb000; }

/* ── Input area override ── */
.stChatInput textarea {
    background-color: #111 !important;
    border: 1px solid #333 !important;
    border-radius: 0 !important;
    color: #e0e0e0 !important;
    font-family: 'IBM Plex Mono', monospace !important;
    font-size: 0.9rem !important;
}
.stChatInput textarea:focus {
    border-color: #ffb000 !important;
    box-shadow: 0 0 0 1px #ffb000 !important;
}

/* ── Chat bubbles ── */
.stChatMessage {
    background: transparent !important;
    border: none !important;
}

/* User message */
.user-msg {
    background-color: #111;
    border: 1px solid #2a2a2a;
    border-left: 3px solid #ffb000;
    padding: 0.85rem 1.1rem;
    margin-bottom: 1rem;
    font-family: 'IBM Plex Sans', sans-serif;
    font-size: 0.95rem;
    color: #e0e0e0;
    border-radius: 0 4px 4px 0;
}
.user-label {
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.65rem;
    color: #ffb000;
    letter-spacing: 0.2em;
    text-transform: uppercase;
    margin-bottom: 0.4rem;
}

/* Answer card */
.answer-card {
    background-color: #0f0f0f;
    border: 1px solid #1e1e1e;
    border-top: 2px solid #ffb000;
    padding: 1.2rem 1.4rem;
    margin-bottom: 1rem;
    border-radius: 0 0 4px 4px;
}
.answer-label {
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.65rem;
    color: #ffb000;
    letter-spacing: 0.2em;
    text-transform: uppercase;
    margin-bottom: 0.6rem;
}
.answer-text {
    font-family: 'IBM Plex Sans', sans-serif;
    font-size: 0.95rem;
    color: #c8c8c8;
    line-height: 1.7;
}

/* Chunk cards */
.chunk-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 0.75rem;
    margin-bottom: 1rem;
}
.chunk-card {
    background-color: #0a0a0a;
    border: 1px solid #1e1e1e;
    padding: 0.9rem;
    border-radius: 2px;
    position: relative;
}
.chunk-card::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 2px;
    background: linear-gradient(90deg, #ffb000, transparent);
}
.chunk-rank {
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.65rem;
    color: #ffb000;
    letter-spacing: 0.2em;
    text-transform: uppercase;
    margin-bottom: 0.3rem;
}
.chunk-meta {
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.62rem;
    color: #444;
    margin-bottom: 0.6rem;
}
.chunk-text {
    font-family: 'IBM Plex Sans', sans-serif;
    font-size: 0.82rem;
    color: #888;
    line-height: 1.6;
}

/* Score bar */
.score-bar-wrap {
    margin-top: 0.5rem;
    background: #1a1a1a;
    height: 3px;
    border-radius: 2px;
    overflow: hidden;
}
.score-bar-fill {
    height: 100%;
    background: #ffb000;
    border-radius: 2px;
}

/* Section divider */
.section-divider {
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.65rem;
    color: #333;
    letter-spacing: 0.25em;
    text-transform: uppercase;
    border-top: 1px solid #1a1a1a;
    padding-top: 0.5rem;
    margin: 1rem 0 0.75rem;
}

/* Hint cards */
.hint-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 0.6rem;
    margin-top: 1.5rem;
}
.hint-card {
    background: #0f0f0f;
    border: 1px solid #1e1e1e;
    padding: 0.75rem 1rem;
    cursor: pointer;
    border-radius: 2px;
    transition: border-color 0.15s;
}
.hint-card:hover { border-color: #ffb000; }
.hint-prefix {
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.6rem;
    color: #ffb000;
    letter-spacing: 0.15em;
    text-transform: uppercase;
    margin-bottom: 0.25rem;
}
.hint-text {
    font-family: 'IBM Plex Sans', sans-serif;
    font-size: 0.82rem;
    color: #666;
    line-height: 1.4;
}

/* Sidebar */
[data-testid="stSidebar"] {
    background-color: #0a0a0a !important;
    border-right: 1px solid #1e1e1e !important;
}
[data-testid="stSidebar"] * { color: #888 !important; }
[data-testid="stSidebar"] .stButton button {
    background: transparent !important;
    border: 1px solid #333 !important;
    color: #ffb000 !important;
    font-family: 'IBM Plex Mono', monospace !important;
    font-size: 0.75rem !important;
    border-radius: 0 !important;
    letter-spacing: 0.1em;
}
[data-testid="stSidebar"] .stButton button:hover {
    border-color: #ffb000 !important;
}

/* Scrollbar */
::-webkit-scrollbar { width: 4px; }
::-webkit-scrollbar-track { background: #0d0d0d; }
::-webkit-scrollbar-thumb { background: #2a2a2a; border-radius: 2px; }
::-webkit-scrollbar-thumb:hover { background: #ffb000; }

/* Spinner */
.stSpinner > div { border-top-color: #ffb000 !important; }
</style>
""", unsafe_allow_html=True)


# ── Sidebar ────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("### ⬡ CONFIG")
    st.divider()

    api_key = st.text_input(
        "OPENROUTER_API_KEY",
        type="password",
        value=os.getenv("OPENROUTER_API_KEY", ""),
        placeholder="sk-or-v1-…",
        help="Free key at openrouter.ai"
    )

    top_k = st.select_slider(
        "RETRIEVE TOP-K",
        options=[1, 2, 3, 4, 5, 6],
        value=3
    )

    st.divider()
    st.markdown("""
```
MODEL   llama-3.3-70b:free
EMBED   all-MiniLM-L6-v2
INDEX   FAISS · FlatIP
CHUNK   500 / 100 overlap
```
""")
    st.divider()

    if st.button("↺  REBUILD INDEX"):
        for k in ["engine", "messages"]:
            st.session_state.pop(k, None)
        st.rerun()

    st.divider()
    st.caption("iNDECIMAL RAG v2 · 2025")


# ── Engine init ────────────────────────────────────────────────────────────────
@st.cache_resource(show_spinner="initialising vector index …")
def get_engine(key: str, k: int) -> RAGEngine:
    return RAGEngine(
        data_dir  = "data",
        store_dir = "vector_store",
        top_k     = k,
        api_key   = key,
    )


# ── Top bar ────────────────────────────────────────────────────────────────────
st.markdown("""
<div class="topbar">
  <div class="topbar-logo">⬡ iNDECIMAL</div>
  <div class="topbar-tag">Construction Intelligence · RAG System v2</div>
</div>
""", unsafe_allow_html=True)

# ── Session state ──────────────────────────────────────────────────────────────
if "messages" not in st.session_state:
    st.session_state.messages = []


# ── Render history ─────────────────────────────────────────────────────────────
def render_chunks(chunks):
    cards = ""
    for c in chunks:
        pct = int(c.get("score", 0) * 100)
        cards += f"""
        <div class="chunk-card">
          <div class="chunk-rank">#{c['rank']} retrieved</div>
          <div class="chunk-meta">src: {c.get('source','?')} · sim: {c.get('score',0):.3f}</div>
          <div class="chunk-text">{c['text']}</div>
          <div class="score-bar-wrap">
            <div class="score-bar-fill" style="width:{pct}%"></div>
          </div>
        </div>"""
    return f'<div class="chunk-grid">{cards}</div>'


for msg in st.session_state.messages:
    if msg["role"] == "user":
        st.markdown(f"""
        <div class="user-msg">
          <div class="user-label">▸ query</div>
          {msg["content"]}
        </div>""", unsafe_allow_html=True)
    else:
        if msg.get("chunks"):
            st.markdown('<div class="section-divider">▸ retrieved context</div>',
                        unsafe_allow_html=True)
            st.markdown(render_chunks(msg["chunks"]), unsafe_allow_html=True)

        st.markdown(f"""
        <div class="answer-card">
          <div class="answer-label">▸ generated answer</div>
          <div class="answer-text">{msg["content"]}</div>
        </div>""", unsafe_allow_html=True)


# ── Empty state ────────────────────────────────────────────────────────────────
HINTS = [
    "What packages does Indecimal offer?",
    "How does the escrow payment model work?",
    "What is the price of the Premier package?",
    "How many quality checkpoints are there?",
    "What does the maintenance program cover?",
    "What steel brands are used in Pinnacle?",
]

if not st.session_state.messages:
    st.markdown("""
    <div style="font-family:'IBM Plex Mono',monospace;font-size:0.7rem;
                color:#444;letter-spacing:0.2em;text-transform:uppercase;
                margin-bottom:0.5rem;">
      ▸ suggested queries
    </div>
    """, unsafe_allow_html=True)

    cols = st.columns(3)
    for i, hint in enumerate(HINTS):
        with cols[i % 3]:
            if st.button(hint, key=f"hint_{i}", use_container_width=True):
                st.session_state._hint = hint
                st.rerun()

    # Status
    st.markdown(f"""
    <div class="status-bar" style="margin-top:2rem;">
      sys: <span>online</span> ·
      docs: <span>3 indexed</span> ·
      model: <span>llama-3.3-70b:free</span> ·
      top-k: <span>{top_k}</span>
    </div>
    """, unsafe_allow_html=True)


# ── Handle hint click ──────────────────────────────────────────────────────────
prompt = None
if hasattr(st.session_state, "_hint"):
    prompt = st.session_state._hint
    del st.session_state._hint


# ── Chat input ─────────────────────────────────────────────────────────────────
user_input = st.chat_input("enter query …")
if user_input:
    prompt = user_input

if prompt:
    st.session_state.messages.append({"role": "user", "content": prompt})

    st.markdown(f"""
    <div class="user-msg">
      <div class="user-label">▸ query</div>
      {prompt}
    </div>""", unsafe_allow_html=True)

    with st.spinner("searching …"):
        try:
            engine = get_engine(api_key, top_k)
            result = engine.query(prompt)
        except Exception as e:
            st.error(str(e))
            st.stop()

    if result["chunks"]:
        st.markdown('<div class="section-divider">▸ retrieved context</div>',
                    unsafe_allow_html=True)
        st.markdown(render_chunks(result["chunks"]), unsafe_allow_html=True)

    st.markdown(f"""
    <div class="answer-card">
      <div class="answer-label">▸ generated answer</div>
      <div class="answer-text">{result['answer']}</div>
    </div>""", unsafe_allow_html=True)

    st.session_state.messages.append({
        "role":    "assistant",
        "content": result["answer"],
        "chunks":  result["chunks"],
    })
